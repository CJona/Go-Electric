<?php

class Category
{
//    public function all(): array
//    {
//        // $db vanuit index.php ophalen
//        global $db;
//
//        return $db->select('Category', '*');
//    }
}